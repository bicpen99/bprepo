Unzip the contents of this archive to the following locations:

- PUD Test Standalone.lnk
	Place on Desktop
- frmsal.jar
	Put this file in c:\temp directory
- run_fsal_tst_pud.cmd
	Put this file in c:\temp directory

Make sure the path to your java.exe is as follows:

C:\Program Files (x86)\Java\jre1.8.0_281\bin\java.exe

if it is not in this path, then edit the 'run_fsal_tst_pud.cmd' file and enter the path to wherever your java.exe is located.

To run the application, click on the PUD Test Standalone.lnk.